package com.demo.weatherapp.util;

import java.math.BigDecimal;

public class TestUtil {

    public static BigDecimal bigDecimal(String value) {
        return new BigDecimal(value);
    }
}
