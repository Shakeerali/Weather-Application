package com.demo.weatherapp.util;

public class Util {
    public static boolean isNotEmpty(String value) {
        return value != null && !value.isEmpty();
    }
}
